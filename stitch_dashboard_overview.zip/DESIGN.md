# Design System Strategy: Desktop Financial Management

## 1. Overview & Creative North Star
This design system is built upon the Creative North Star of **"The Fiscal Sanctuary."** Moving away from the cluttered, high-anxiety aesthetic of traditional banking, this system prioritizes a spacious, editorial layout that feels both authoritative and approachable. 

The transition from mobile to desktop is not merely a stretching of elements, but a reimagining of space. We leverage **intentional asymmetry** and **high-contrast typography scales** to create a sophisticated, data-driven environment. By utilizing wide margins, overlapping "frosted" surfaces, and a deliberate lack of harsh containment lines, we transform a simple budget tracker into a premium digital experience.

## 2. Colors
Our palette balances the deep, trustworthy weight of Navy with the kinetic energy of Vibrant Green and Slate Blue.

### The Palette (Material Design Tokens)
- **Primary (Core Navy):** `#212455` (The anchor of the brand)
- **Secondary (Vibrant Green):** `#B0D365` (Action, growth, and positive status)
- **Tertiary (Slate Blue):** `#5663AD` (Secondary actions and navigational accents)
- **Surface Hierarchy:** 
    - `surface`: `#fef7fe` (The base canvas)
    - `surface-container-low`: `#f8f2f9` (Subtle grouping)
    - `surface-container-highest`: `#e6e1e8` (Deep contrast for secondary data)

### Core Color Rules
*   **The "No-Line" Rule:** 1px solid borders for sectioning are strictly prohibited. Section boundaries must be defined through background color shifts (e.g., a `surface-container-low` dashboard card sitting on a `surface` background) or tonal transitions.
*   **The Glass & Gradient Rule:** To avoid a "flat" SaaS feel, floating elements (modals, dropdowns) must use a Glassmorphic effect: `surface` colors at 80% opacity with a `20px` backdrop-blur. 
*   **Signature Textures:** Main CTA buttons and Hero charts should utilize a subtle linear gradient from `primary` (#212455) to `primary_container` (#3f4275) to provide depth and professional polish.

## 3. Typography
We use a high-contrast editorial scale to lead the user’s eye through complex financial data.

*   **Display & Headlines (National Park):** Use this clean, rounded sans-serif for high-level numbers and page titles. The rounded terminals mirror the "Bag" logo, maintaining friendliness in a data-heavy environment.
    *   *Headline-LG:* 2rem, `plusJakartaSans` weight 600.
*   **Title & Personality (Pain de Mie):** This playful typeface is reserved for "Budget Wins," "Financial Milestones," or friendly empty-state messaging. Use it sparingly to inject brand personality without compromising readability.
*   **Body & Labels (Work Sans):** A highly legible sans-serif for transaction lists, input fields, and fine print.
    *   *Body-LG:* 1rem (Primary data points).
    *   *Label-MD:* 0.75rem (Uppercase metadata or secondary category labels).

## 4. Elevation & Depth
In this system, hierarchy is communicated through **Tonal Layering** rather than structural lines.

*   **The Layering Principle:** Depth is achieved by stacking surface-container tiers. Place a `surface_container_lowest` card on a `surface_container_low` section to create a soft, natural lift.
*   **Ambient Shadows:** For floating components like the "Add Transaction" modal, use extra-diffused shadows.
    *   *Shadow Specs:* `0px 24px 48px rgba(33, 36, 85, 0.06)`. The tint is derived from the `on_surface` color to mimic natural ambient light.
*   **The "Ghost Border" Fallback:** If containment is absolutely required for accessibility, use a `1px` border of `outline_variant` at **15% opacity**.
*   **Subtle Accents:** Incorporate the 'star' and 'dollar' patterns as low-contrast watermarks (Opacity 3-5%) within `surface_container_highest` sections to break up large monochromatic blocks.

## 5. Components

### Buttons
*   **Primary:** Solid `primary` gradient with `on_primary` text. `1.5rem` (xl) corner radius for a "pill" look that feels friendly.
*   **Secondary:** `surface_container_highest` background with `on_primary_container` text. No border.

### Category Cards (Desktop)
*   **Style:** Forbid divider lines. Use `3.5rem` (10) vertical spacing between cards.
*   **Visuals:** Each card uses a `secondary` (Vibrant Green) progress bar. The bar should be thick (`0.7rem`) with a `full` radius.

### Input Fields
*   **Style:** `surface_container_low` fill. No border until focus. On focus, use a `primary` 1.5px "Ghost Border" at 40% opacity.
*   **Labels:** Use `Work Sans` Label-MD, positioned strictly above the input area with a `0.7rem` (2) gap.

### Transaction Lists
*   **Style:** Alternating rows of `surface` and `surface_container_low`. 
*   **Typography:** The amount (e.g., -$75.20) should be rendered in `National Park` Title-MD to ensure the most important data stands out.

## 6. Do's and Don'ts

### Do
*   **DO** use whitespace as a structural tool. Let the data "breathe" in the spacious desktop layout.
*   **DO** use the `secondary_fixed_dim` (#b0d365) for positive financial trends to reinforce growth.
*   **DO** ensure all interactive elements have a minimum target of 44px, even on desktop, to maintain the "approachable" feel.

### Don't
*   **DON'T** use 100% black for text. Always use `on_background` (#1d1b20) or `on_surface_variant` (#46464f) to maintain the sophisticated tonal palette.
*   **DON'T** use traditional "Drop Shadows" with high opacity. They break the "Fiscal Sanctuary" minimalism.
*   **DON'T** use the 'Pain de Mie' font for primary data or body text; it is a decorative tool only.